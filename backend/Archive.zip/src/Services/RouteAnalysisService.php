<?php

declare(strict_types=1);

namespace FloodGuard\Services;

use FloodGuard\Config\Config;
use FloodGuard\Database\Database;
use FloodGuard\Support\CacheStore;
use FloodGuard\Support\HttpClient;

final class RouteAnalysisService
{
    private CacheStore $cache;
    private PredictionService $prediction;
    private FloodDataService $floodData;
    private RiskEngine $riskEngine;
    private GeminiService $gemini;
    private \PDO $db;

    public function __construct()
    {
        $this->cache = new CacheStore();
        $this->prediction = new PredictionService();
        $this->floodData = new FloodDataService();
        $this->riskEngine = new RiskEngine();
        $this->gemini = new GeminiService();
        $this->db = Database::connection();
    }

    /**
     * @return array<string, mixed>
     */
    public function analyze(
        float $fromLat,
        float $fromLng,
        string $fromName,
        float $toLat,
        float $toLng,
        string $toName,
        string $time,
        string $language = 'en'
    ): array {
        $cacheKey = sprintf(
            'route:%.4f:%.4f:%.4f:%.4f:%s:%s',
            $fromLat,
            $fromLng,
            $toLat,
            $toLng,
            $time,
            $language
        );
        $cached = $this->cache->get($cacheKey);
        if ($cached !== null) {
            return $cached;
        }

        $predictionFrom = $this->prediction->predict($fromLat, $fromLng, $fromName, $language);
        $predictionTo = $this->prediction->predict($toLat, $toLng, $toName, $language);
        $baseRisk = (int) round(((int) $predictionFrom['flood_probability'] + (int) $predictionTo['flood_probability']) / 2);

        $rawRoutes = $this->fetchRoutes($fromLat, $fromLng, $toLat, $toLng);
        $alternatives = [];
        $primarySegments = [];
        $best = null;

        foreach ($rawRoutes as $index => $route) {
            $segments = $this->segmentRisks($route['points'], $baseRisk);
            $risk = $this->riskEngine->compute(
                hourlyRain: [($baseRisk / 10)],
                historySeverities: [max(1, (int) round($baseRisk / 20))],
                reportDepthsCm: [max(5, (int) round($baseRisk / 3))],
                routeSegmentRisks: $segments
            );
            $candidate = [
                'route' => $route['label'],
                'risk_percent' => $risk['risk_percent'],
                'recommended_time' => $risk['risk_percent'] >= 60 ? '19:00' : $time,
                'segments' => $segments,
            ];
            if ($index === 0) {
                $primarySegments = $segments;
            } else {
                $alternatives[] = [
                    'route' => $candidate['route'],
                    'risk_percent' => $candidate['risk_percent'],
                    'recommended_time' => $candidate['recommended_time'],
                ];
            }
            if ($best === null || $candidate['risk_percent'] < $best['risk_percent']) {
                $best = $candidate;
            }
        }

        $baseRouteRisk = $best['risk_percent'] ?? $baseRisk;
        $ai = $this->gemini->routeDecision([
            'language' => $language,
            'from' => $fromName,
            'to' => $toName,
            'time' => $time,
            'base_risk_percent' => $baseRouteRisk,
            'segment_risks' => $primarySegments,
            'alternatives' => $alternatives,
            'prediction_from' => $predictionFrom,
            'prediction_to' => $predictionTo,
        ]);

        $result = [
            'decision' => (string) ($ai['decision'] ?? ($baseRouteRisk >= 60 ? 'Unsafe' : 'Safe')),
            'risk_percent' => (int) ($ai['risk_percent'] ?? $baseRouteRisk),
            'recommended_time' => (string) ($ai['recommended_time'] ?? ($baseRouteRisk >= 60 ? '19:00' : $time)),
            'recommended_action' => (string) ($ai['recommended_action'] ?? 'Avoid low-lying roads and monitor live alerts.'),
            'alternatives' => is_array($ai['alternatives'] ?? null) ? $ai['alternatives'] : $alternatives,
        ];

        $this->saveRoute($fromName, $toName, $result['risk_percent'], $primarySegments);
        $ttl = (int) Config::get('ROUTE_CACHE_TTL', 300);
        $this->cache->put($cacheKey, $result, $ttl);

        return $result;
    }

    /**
     * @return array<int, array{label: string, points: array<int, array{lat: float, lng: float}>}>
     */
    private function fetchRoutes(float $fromLat, float $fromLng, float $toLat, float $toLng): array
    {
        $apiKey = (string) Config::get('GOOGLE_MAPS_API_KEY', '');
        if ($apiKey === '') {
            return $this->fallbackRoutes($fromLat, $fromLng, $toLat, $toLng);
        }

        $url = sprintf(
            'https://maps.googleapis.com/maps/api/directions/json?origin=%s,%s&destination=%s,%s&alternatives=true&key=%s',
            $fromLat,
            $fromLng,
            $toLat,
            $toLng,
            urlencode($apiKey)
        );
        $response = HttpClient::get($url);
        $routes = $response['body']['routes'] ?? [];
        if (!is_array($routes) || count($routes) === 0) {
            return $this->fallbackRoutes($fromLat, $fromLng, $toLat, $toLng);
        }

        $results = [];
        foreach (array_slice($routes, 0, 3) as $index => $route) {
            if (!is_array($route)) {
                continue;
            }
            $polyline = (string) ($route['overview_polyline']['points'] ?? '');
            $points = $this->decodePolyline($polyline);
            if (count($points) < 2) {
                continue;
            }
            $results[] = [
                'label' => 'Route ' . ($index + 1),
                'points' => $points,
            ];
        }
        return count($results) > 0 ? $results : $this->fallbackRoutes($fromLat, $fromLng, $toLat, $toLng);
    }

    /**
     * @return array<int, array{label: string, points: array<int, array{lat: float, lng: float}>}>
     */
    private function fallbackRoutes(float $fromLat, float $fromLng, float $toLat, float $toLng): array
    {
        return [
            [
                'label' => 'Primary Corridor',
                'points' => [
                    ['lat' => $fromLat, 'lng' => $fromLng],
                    ['lat' => ($fromLat + $toLat) / 2 + 0.012, 'lng' => ($fromLng + $toLng) / 2 + 0.006],
                    ['lat' => $toLat, 'lng' => $toLng],
                ],
            ],
            [
                'label' => 'Alternative 1',
                'points' => [
                    ['lat' => $fromLat, 'lng' => $fromLng],
                    ['lat' => ($fromLat + $toLat) / 2 - 0.011, 'lng' => ($fromLng + $toLng) / 2 + 0.004],
                    ['lat' => $toLat, 'lng' => $toLng],
                ],
            ],
            [
                'label' => 'Alternative 2',
                'points' => [
                    ['lat' => $fromLat, 'lng' => $fromLng],
                    ['lat' => ($fromLat + $toLat) / 2 + 0.003, 'lng' => ($fromLng + $toLng) / 2 - 0.009],
                    ['lat' => $toLat, 'lng' => $toLng],
                ],
            ],
        ];
    }

    /**
     * @param array<int, array{lat: float, lng: float}> $points
     * @return array<int, float>
     */
    private function segmentRisks(array $points, int $baseRisk): array
    {
        $segmentRisks = [];
        $distanceAccum = 0.0;
        $totalDistance = 0.0;

        for ($i = 1; $i < count($points); $i++) {
            $totalDistance += $this->distanceMeters($points[$i - 1], $points[$i]);
        }
        if ($totalDistance <= 0) {
            return [$baseRisk];
        }

        for ($i = 1; $i < count($points); $i++) {
            $segmentDistance = $this->distanceMeters($points[$i - 1], $points[$i]);
            $distanceAccum += $segmentDistance;
            if ($distanceAccum < 250 && $i < count($points) - 1) {
                continue;
            }

            $ratio = min(1.0, $distanceAccum / $totalDistance);
            $variation = (int) round(($ratio - 0.5) * 20);
            $localHistory = $this->floodData->historySeverities($points[$i]['lat'], $points[$i]['lng']);
            $localReports = $this->floodData->reportDepths($points[$i]['lat'], $points[$i]['lng']);
            $local = $this->riskEngine->compute(
                hourlyRain: [($baseRisk / 12)],
                historySeverities: $localHistory,
                reportDepthsCm: $localReports
            );
            $segmentRisks[] = (float) max(0, min(100, $local['risk_percent'] + $variation));
            $distanceAccum = 0.0;
        }

        return count($segmentRisks) > 0 ? $segmentRisks : [$baseRisk];
    }

    /**
     * @param array{lat: float, lng: float} $a
     * @param array{lat: float, lng: float} $b
     */
    private function distanceMeters(array $a, array $b): float
    {
        $earthRadius = 6371000.0;
        $dLat = deg2rad($b['lat'] - $a['lat']);
        $dLng = deg2rad($b['lng'] - $a['lng']);
        $lat1 = deg2rad($a['lat']);
        $lat2 = deg2rad($b['lat']);

        $haversine = sin($dLat / 2) ** 2 + cos($lat1) * cos($lat2) * sin($dLng / 2) ** 2;
        return 2 * $earthRadius * asin(min(1, sqrt($haversine)));
    }

    /**
     * @return array<int, array{lat: float, lng: float}>
     */
    private function decodePolyline(string $encoded): array
    {
        if ($encoded === '') {
            return [];
        }

        $points = [];
        $index = 0;
        $lat = 0;
        $lng = 0;
        $length = strlen($encoded);

        while ($index < $length) {
            $result = 0;
            $shift = 0;
            do {
                $b = ord($encoded[$index++]) - 63;
                $result |= ($b & 0x1f) << $shift;
                $shift += 5;
            } while ($b >= 0x20 && $index < $length);
            $deltaLat = (($result & 1) ? ~($result >> 1) : ($result >> 1));
            $lat += $deltaLat;

            $result = 0;
            $shift = 0;
            do {
                $b = ord($encoded[$index++]) - 63;
                $result |= ($b & 0x1f) << $shift;
                $shift += 5;
            } while ($b >= 0x20 && $index < $length);
            $deltaLng = (($result & 1) ? ~($result >> 1) : ($result >> 1));
            $lng += $deltaLng;

            $points[] = ['lat' => $lat / 1e5, 'lng' => $lng / 1e5];
        }
        return $points;
    }

    /**
     * @param array<int, float> $segmentRisks
     */
    private function saveRoute(string $source, string $destination, int $riskScore, array $segmentRisks): void
    {
        $insert = $this->db->prepare(
            'INSERT INTO routes (source, destination, risk_score, created_at)
             VALUES (:source, :destination, :risk_score, UTC_TIMESTAMP())'
        );
        $insert->execute([
            'source' => $source,
            'destination' => $destination,
            'risk_score' => $riskScore,
        ]);
        $routeId = (int) $this->db->lastInsertId();

        $segmentInsert = $this->db->prepare(
            'INSERT INTO route_segments (route_id, segment_index, risk_score, created_at)
             VALUES (:route_id, :segment_index, :risk_score, UTC_TIMESTAMP())'
        );
        foreach ($segmentRisks as $index => $segmentRisk) {
            $segmentInsert->execute([
                'route_id' => $routeId,
                'segment_index' => $index,
                'risk_score' => (int) round($segmentRisk),
            ]);
        }
    }
}
