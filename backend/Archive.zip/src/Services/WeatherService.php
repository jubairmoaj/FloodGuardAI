<?php

declare(strict_types=1);

namespace FloodGuard\Services;

use FloodGuard\Config\Config;
use FloodGuard\Support\CacheStore;
use FloodGuard\Support\HttpClient;

final class WeatherService
{
    private CacheStore $cache;

    public function __construct()
    {
        $this->cache = new CacheStore();
    }

    /**
     * @return array{hourly_rain: array<int, float>, source: string}
     */
    public function hourlyRain(float $lat, float $lng): array
    {
        $cacheKey = sprintf('weather:%.4f:%.4f', $lat, $lng);
        $cached = $this->cache->get($cacheKey);
        if ($cached !== null) {
            return [
                'hourly_rain' => $cached['hourly_rain'] ?? [],
                'source' => 'cache',
            ];
        }

        $apiKey = (string) Config::get('OPENWEATHER_API_KEY', '');
        if ($apiKey === '') {
            return $this->fallbackRain($cacheKey);
        }

        $url = sprintf(
            'https://api.openweathermap.org/data/3.0/onecall?lat=%s&lon=%s&exclude=minutely,daily,alerts&units=metric&appid=%s',
            $lat,
            $lng,
            $apiKey
        );
        $response = HttpClient::get($url);
        $hourly = $response['body']['hourly'] ?? [];
        if (!is_array($hourly) || count($hourly) === 0) {
            return $this->fallbackRain($cacheKey);
        }

        $rain = [];
        for ($i = 0; $i < min(12, count($hourly)); $i++) {
            $entry = $hourly[$i];
            if (!is_array($entry)) {
                continue;
            }
            $rain[] = (float) ($entry['rain']['1h'] ?? 0.0);
        }

        if (count($rain) === 0) {
            return $this->fallbackRain($cacheKey);
        }

        $ttl = (int) Config::get('WEATHER_CACHE_TTL', 600);
        $this->cache->put($cacheKey, ['hourly_rain' => $rain], $ttl);

        return [
            'hourly_rain' => $rain,
            'source' => 'openweather',
        ];
    }

    /**
     * @return array{hourly_rain: array<int, float>, source: string}
     */
    private function fallbackRain(string $cacheKey): array
    {
        $fallback = [2.1, 3.4, 4.6, 6.2, 5.1, 3.8, 2.2, 1.4, 0.9, 0.6, 0.5, 0.3];
        $ttl = (int) Config::get('WEATHER_CACHE_TTL', 600);
        $this->cache->put($cacheKey, ['hourly_rain' => $fallback], $ttl);

        return [
            'hourly_rain' => $fallback,
            'source' => 'fallback',
        ];
    }
}
